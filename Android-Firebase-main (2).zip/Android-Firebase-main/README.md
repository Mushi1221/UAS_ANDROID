# Android-Firebase
Repository ini dibuat untuk memenuhi tugas UAS  - Pemrograman Mobile

Nama    :   Aditya Achya Ananta Nur

Nim     :   312210714

Kelas   :   TI.22.B1

## Fitur-Fitur Yang Ada Di Android-Fragment Yang Kelompok Kami Buat

![Screenshot 2024-07-08 223532](https://github.com/AdityaAchya/Android-Firebase/assets/123864099/664b82e2-db3c-4e5d-9d15-eceae3a70999)

![Screenshot 2024-07-08 223225](https://github.com/AdityaAchya/Android-Firebase/assets/123864099/412b3b70-ccb2-4c59-b288-bafbb5079e9f)

![Screenshot 2024-07-08 223334](https://github.com/AdityaAchya/Android-Firebase/assets/123864099/40e794df-5544-4265-9090-662943f00a5b)

![Screenshot 2024-07-08 223359](https://github.com/AdityaAchya/Android-Firebase/assets/123864099/c320b2ad-5d39-4f84-8150-8c641b3db59f)

![Screenshot 2024-07-08 223414](https://github.com/AdityaAchya/Android-Firebase/assets/123864099/06a3eabd-8887-4053-b445-a5d3e60a7296)

![Screenshot 2024-07-08 223444](https://github.com/AdityaAchya/Android-Firebase/assets/123864099/081f80fd-c86f-49f3-aef6-bebc8419e640)

## LINK YOUTUBE PENJELASAN FITUR-FITUR 
https://youtu.be/bTdUS-RxAas

## Penjelasan
[Project mobile kelompok 6_Kas RT.pdf](https://github.com/user-attachments/files/16131486/Project.mobile.kelompok.6_Kas.RT.pdf)
